-- related to ticket https://jira.onsemi.com/browse/CE-1101

ALTER TABLE ON_SLICE ADD GLOBAL_WAFER_ID VARCHAR2(32);