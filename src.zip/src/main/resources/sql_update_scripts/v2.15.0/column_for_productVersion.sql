-- related to ticket https://jira.onsemi.com/browse/CE-2615

ALTER TABLE ON_PROD ADD PRODUCT_VERSION VARCHAR2(128);