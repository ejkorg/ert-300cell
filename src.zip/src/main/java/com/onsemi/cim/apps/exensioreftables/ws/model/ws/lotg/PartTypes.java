package com.onsemi.cim.apps.exensioreftables.ws.model.ws.lotg;

/**
 *
 * @author ffv7xh
 */
public enum PartTypes {
    UNKNOWN, POLY, RWFR, EPI, SWFR, WAFER, WFR, DIE, BUMP, DIESALES, RS, FG, FG_SHIPPED, M00
}
