package com.onsemi.cim.apps.exensioreftables.ws.entity.application;

/**
 *
 * @author fg6zdy
 */
public enum MesType {
    GENESIS,
    TORRENT,
    OTHER,
}
