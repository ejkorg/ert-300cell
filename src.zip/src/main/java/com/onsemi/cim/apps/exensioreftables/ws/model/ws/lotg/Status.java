package com.onsemi.cim.apps.exensioreftables.ws.model.ws.lotg;

/**
 *
 * @author ffv7xh
 */
public enum Status {
    Unknown,
    Found,
    Found_BOM,
    Not_Found_Start_Lot,
    No_Data,
    Error
}
