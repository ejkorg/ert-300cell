package com.onsemi.cim.apps.exensioreftables.ws.entity.application;

/**
 *
 * @author fg6zdy
 */
public enum LotIdForOnScribeType {
    UNKNOWN,
    LOT_ID,
    MFG_LOT
}
