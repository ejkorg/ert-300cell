package com.onsemi.cim.apps.exensioreftables.ws.model.ws.lotg;

/**
 *
 * @author ffv7xh
 */
public enum TraceabilityDirection {
    Parents,
    Children
}
